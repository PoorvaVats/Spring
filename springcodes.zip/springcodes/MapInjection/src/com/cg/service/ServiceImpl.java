package com.cg.service;

import java.util.Map;
import java.util.Properties;

import com.cg.entity.Emp;

public class ServiceImpl implements IService {

	private Map<Integer, Emp> emap;
	
	//injecting a map
	public ServiceImpl(Map<Integer, Emp> emap) {
		super();
		this.emap = emap;
	}

	@Override
	public Emp getEmployee(int eid) {
		return emap.get(eid);
	}
	
}
