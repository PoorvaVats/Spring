package com.cg.service;

import com.cg.entity.Emp;

public interface IService {
	
	Emp getEmployee(int eid);

}
