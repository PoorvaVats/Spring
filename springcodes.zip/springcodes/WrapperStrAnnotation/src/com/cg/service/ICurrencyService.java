package com.cg.service;

public interface ICurrencyService {
	
	double convertToINR(double usd);
	String currentState();

}
