package com.cg.client.annotation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cg.service.CarFactory;
import com.cg.service.CarService;

@Configuration
public class MyConfig {
	
	@Bean(name = "car1")
	public CarFactory getCar() {
		return new CarFactory();
	}
	
	@Bean(name = "car2")
	public CarService getCar2() {
		return new CarService();
	}
}
