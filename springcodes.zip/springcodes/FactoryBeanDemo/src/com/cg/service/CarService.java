package com.cg.service;

public class CarService {
	
	public void drive() {
		System.out.println("Car Service");
	}
}
