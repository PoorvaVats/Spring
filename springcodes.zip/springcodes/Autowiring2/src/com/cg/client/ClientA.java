package com.cg.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.service.Shape;

public class ClientA {
	
	static ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");

	public static void main(String[] args) {
		System.out.println("main start");
		Shape shape = ctx.getBean("myser", Shape.class);
		System.out.println(shape.calcArea());

	}

}
