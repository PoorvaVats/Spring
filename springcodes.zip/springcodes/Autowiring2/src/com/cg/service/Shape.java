package com.cg.service;

public interface Shape {
	double calcArea();
}
