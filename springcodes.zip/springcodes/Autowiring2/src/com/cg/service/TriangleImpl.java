package com.cg.service;

public class TriangleImpl implements Shape {

	private Point p1;
	private Point p2;
	private Point p3;

	public void setP1(Point p1) {
		this.p1 = p1;
	}

	public void setP2(Point p2) {
		this.p2 = p2;
	}

	public void setP3(Point p3) {
		this.p3 = p3;
	}

	/*
	 * public TriangleImpl() {
	 * 
	 * }
	 */

	public TriangleImpl(Point p1, Point p2, Point p3) {
		
		super();
		this.p1 = p1;
		this.p2 = p2;
		this.p3 = p3;
		
	}

	@Override
	public double calcArea() {
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		double height = p2.getY() - p1.getX();
		double base = Math.sqrt(Math.pow(p3.getX() - p2.getX(), 2) + Math.pow(p3.getY() - p2.getY(), 2));
		return 0.5 * height * base;
	}

}
