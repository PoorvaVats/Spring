package com.cg.service;

public interface IService {

	String sayHello(String str);
	
}
