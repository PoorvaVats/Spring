package com.cg.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.service.IService;

public class ClientA {
	
	static ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");

	public static void main(String[] args) {
		System.out.println("main starts");
		IService ser = ctx.getBean("myser", IService.class);
		String res = ser.getData("driver");
		if (res != null) {
			System.out.println(res);
		}
		
	}

}
