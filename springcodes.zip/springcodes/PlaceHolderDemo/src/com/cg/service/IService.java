package com.cg.service;

public interface IService {
	
	String getData(String property);

}
