package com.cg.client;

import java.util.Arrays;
import java.util.List;


import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cg.entity.Account;
import com.cg.service.AccountService;

public class AddListOfAccount {
	
	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(JpaConfiguration.class);
		AccountService service = ctx.getBean("accountser", AccountService.class);
		List<Account> lst = Arrays.asList(
					new Account(1003, "sai", 50000),
					new Account(1004, "mahesh", 60000)
				);
		service.addAccount(lst);
		System.out.println("accounts created");
	}

}
