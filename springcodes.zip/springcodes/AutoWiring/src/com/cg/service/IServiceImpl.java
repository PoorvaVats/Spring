package com.cg.service;

import com.cg.dao.IDao;

public class IServiceImpl implements IService {
	
	
	private IDao dao;
	
	public IServiceImpl() {
		System.out.println("Service Consstructor");
	}
	
//	//constructor is used by Ioc to inject
//	public IServiceImpl(IDao dao) {
//		super();
//		System.out.println("Injecting dao, service constructor fires");
//		this.dao = dao;
//	}
//	
	public void setDao(IDao dao) {
		this.dao = dao;
	}

	@Override
	public String viewName() {
		return dao.getName();
	}

}
