package com.cg.service;

public interface IService {
	
	public String viewName();

}
