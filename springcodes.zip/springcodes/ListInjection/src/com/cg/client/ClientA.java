package com.cg.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.service.ISeracher;

public class ClientA {
	
	static ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");

	public static void main(String[] args) {
		System.out.println("main starts");
		ISeracher ser = ctx.getBean("myser", ISeracher.class);
		System.out.println(ser.search("jammu"));
		System.out.println(ser.searchStartWith("ja"));
		System.out.println(ser.displayAll());
		
	}

}
