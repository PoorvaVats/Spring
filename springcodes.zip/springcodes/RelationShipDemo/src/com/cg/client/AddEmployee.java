package com.cg.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.entity.Dept;
import com.cg.entity.Emp;

public class AddEmployee {
	
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-CRUD");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		Dept dept = new Dept();
		dept.setDeptId(3);
		Emp emp = new Emp();
		emp.setEmpId(1006);
		emp.setEmpName("agay sharma");
		emp.setEmpSal(49000);
		emp.setDept(dept);
		
		em.persist(emp);
		
		tx.commit();
		em.close();
		emf.close();
		
	}

}
