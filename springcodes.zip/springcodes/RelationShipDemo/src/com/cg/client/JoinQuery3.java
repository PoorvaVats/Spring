package com.cg.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.entity.Emp;
import com.cg.entity.Rating;

public class JoinQuery3 {

	static EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-CRUD");

	public static void main(String[] args) {

		EntityManager em = emf.createEntityManager();

		String jpql = "from Rating r inner join fetch r.emp e inner join fetch e.dept";
		TypedQuery<Rating> qry = em.createQuery(jpql, Rating.class);
		List<Rating> list = qry.getResultList();
		em.close();
		emf.close();
		
		list.forEach(rating -> {
			System.out.println(rating);
			System.out.println(rating.getEmp());
			System.out.println(rating.getEmp().getDept());
			System.out.println("-----------------------------------------");
		});

	}

}
