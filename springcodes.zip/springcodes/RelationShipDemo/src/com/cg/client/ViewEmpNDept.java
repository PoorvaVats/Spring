package com.cg.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Dept;
import com.cg.entity.Emp;

public class ViewEmpNDept {

	static EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-CRUD");
	
	public static void main(String[] args) {
		EntityManager em = emf.createEntityManager();
		Emp emp = em.find(Emp.class, 1003);
		em.close();
		emf.close();
		System.out.println(emp);
		Dept dept = emp.getDept();
		System.out.println(dept);

	}

}
