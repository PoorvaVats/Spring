package com.cg.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.entity.Dept;
import com.cg.entity.Emp;
import com.cg.entity.Rating;

public class AddRating {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-CRUD");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		Emp emp = new Emp();
		emp.setEmpId(1002);
		Rating rating = new Rating();
		rating.setId(2);
		rating.setPname("ecommerce");
		rating.setRating(8);
		rating.setEmp(emp);
		em.persist(rating);
		tx.commit();
		em.close();
		emf.close();

	}

}
