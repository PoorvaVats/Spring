package com.cg.client;

import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Hibernate;

import com.cg.entity.Dept;
import com.cg.entity.Emp;

public class ViewDeptAndEmp {

	static EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-CRUD");
	public static void main(String[] args) {
	
		//Dept dept = getDept(1);
		Dept dept = getDeptNEmployee(2);
		System.out.println("-------------------------------------------");
		System.out.println(dept.getDeptId() + "  " + dept.getDeptName());
		System.out.println("-------------------------------------------");
		Set<Emp> employees = dept.getEmployees();
		employees.forEach(System.out::println);
		
		emf.close();
	}
	
	public static Dept getDept(int id) {
		EntityManager em = emf.createEntityManager();
		Dept dept = em.find(Dept.class, id);
		em.close();
		return dept;
	}
	
	public static Dept getDeptNEmployee(int id) {
		EntityManager em = emf.createEntityManager();
		Dept dept = em.find(Dept.class, id);
		Hibernate.initialize(dept.getEmployees());// demand child instances
		em.close();
		return dept;
	}

}
