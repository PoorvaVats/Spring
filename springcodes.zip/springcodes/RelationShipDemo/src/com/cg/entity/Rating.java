package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "lpu_rating")
public class Rating {
	
	@Id
	private int id;
	
	@Column(length = 20)
	private String pname;
	private int rating;
	
	@OneToOne
	@JoinColumn(name = "emp_id", referencedColumnName = "eid", unique = true)
	private Emp emp;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public Emp getEmp() {
		return emp;
	}
	public void setEmp(Emp emp) {
		this.emp = emp;
	}
	
	@Override
	public String toString() {
		return "Rating [id=" + id + ", pname=" + pname + ", rating=" + rating + ", emp=" + emp + "]";
	}
	
	

}
