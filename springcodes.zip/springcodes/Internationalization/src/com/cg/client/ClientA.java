package com.cg.client;

import java.util.Locale;

import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClientA {
	
	static ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
	
	public static void main(String[] args) {
		System.out.println("main starts");
		MessageSource messageSource = ctx.getBean("messageSource", MessageSource.class);
		Object[] objects = new Object[] {"ram"};
		String german = messageSource.getMessage("welcome", objects, Locale.GERMAN);
		System.out.println(german);
		String french = messageSource.getMessage("welcome", objects, Locale.FRENCH);
		System.out.println(french);
	}

}
