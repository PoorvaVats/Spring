package com.cg.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class DistintDemo {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-CRUD");
		EntityManager em = emf.createEntityManager();
		String jpql = "select distinct(empDept) from Emp";
		TypedQuery<String> qry = em.createQuery(jpql, String.class);
		List<String> lst = qry.getResultList();
		qry.setFirstResult(2);
		qry.setMaxResults(5);
		em.close();
		emf.close();
		
		lst.forEach(System.out::println);
		

	}

}
