package com.cg.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.entity.Emp;

public class NamedQueryDemo {

	static EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-CRUD");

	public static void main(String[] args) {

		EntityManager em = emf.createEntityManager();
		
		TypedQuery<Emp> qry = em.createNamedQuery("searchByDept", Emp.class);
		qry.setParameter("dname", "Hr");
		List<Emp> elist = qry.getResultList();
		em.close();
		emf.close();
		elist.forEach(System.out::println);

	}

}
