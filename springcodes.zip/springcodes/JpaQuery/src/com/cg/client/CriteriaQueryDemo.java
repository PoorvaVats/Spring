package com.cg.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import com.cg.entity.Emp;

public class CriteriaQueryDemo {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-CRUD");
		EntityManager em = emf.createEntityManager();
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Emp> cq = cb.createQuery(Emp.class);
		Root<Emp> stud = cq.from(Emp.class);
		
		cq.orderBy(cb.desc(stud.get("empSal")));
		
		cq.where(cb.equal(stud.get("empDept"), "Hr"));
		
		CriteriaQuery<Emp> select = cq.select(stud);
		TypedQuery<Emp> q = em.createQuery(select);
		List<Emp> list = q.getResultList();
		list.forEach(System.out::println);
		
		em.close();
		emf.close();

	}

}
