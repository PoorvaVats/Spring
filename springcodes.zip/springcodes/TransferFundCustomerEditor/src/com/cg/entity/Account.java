package com.cg.entity;

public class Account {
	
	private int accId;
	private String custName;
	private double balance;
	

	public int getAccId() {
		return accId;
	}

	public void setAccId(int accId) {
		this.accId = accId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String name) {
		this.custName = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [accId=" + accId + ", accNameString=" + custName + ", balance=" + balance + "]";
	}

	
	
	
	

}
