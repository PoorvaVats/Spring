package com.cg.dao;

import java.util.Map;

import com.cg.entity.Account;

public class AccountDaoImpl implements IAccountDao {
	
	private Map<Integer, Account> amap;
	
	public void setAmap(Map<Integer, Account> amap) {
		this.amap = amap;
	}

	@Override
	public Account getAccount(int aid) {
		return amap.get(aid);
	}

}
