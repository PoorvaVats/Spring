package com.cg.dao;

import com.cg.entity.Account;

public interface IAccountDao {
	
	Account getAccount(int aid);

}
