package com.cg.service;

import com.cg.entity.Account;

public interface IAccountService {
	
	Account viewAccount(int aid);
	boolean transferFund(int fromId, int toId, double amt);
}
