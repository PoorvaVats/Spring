package com.cg.service;

import java.beans.PropertyEditorSupport;

import com.cg.entity.Account;

public class AccEditor extends PropertyEditorSupport {
	
	@Override
	public String getAsText() {
		return getValue().toString();
	}
	
	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		String[] args = text.split(",");
		Account account = new Account();
		account.setAccId(Integer.parseInt(args[0].trim()));
		account.setCustName(args[1].trim());
		account.setBalance(Double.parseDouble(args[2].trim()));
		setValue(account);
	}

}
