package com.cg.service;

import com.cg.dao.IAccountDao;
import com.cg.entity.Account;

public class AccountSerImpl implements IAccountService {
	
	private IAccountDao dao;

	public AccountSerImpl(IAccountDao dao) {
		super();
		this.dao = dao;
	}

	@Override
	public Account viewAccount(int aid) {
		return dao.getAccount(aid);
	}

	@Override
	public boolean transferFund(int fromId, int toId, double amt) {
		Account fromAccount = dao.getAccount(fromId);
		if (fromAccount == null) return false;
		
		Account toAccount = dao.getAccount(toId);
		if (toAccount == null) return false;
		
		if (fromAccount.getBalance() >= amt) {
			fromAccount.setBalance(fromAccount.getBalance() - amt);
			toAccount.setBalance(toAccount.getBalance() + amt);
		}
		
		return true;
	}

}
