package com.cg.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.service.IAccountService;

public class ClientA {
	
	static ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");

	public static void main(String[] args) {
		System.out.println("main starts");
		IAccountService service = ctx.getBean("myser", IAccountService.class);
		System.out.println(service.viewAccount(1001));
		System.out.println(service.viewAccount(1002));
		boolean res = service.transferFund(1001, 1002, 10000);
		System.out.println("transfered " + res);
		System.out.println(service.viewAccount(1001));
		System.out.println(service.viewAccount(1002));
	}

}
